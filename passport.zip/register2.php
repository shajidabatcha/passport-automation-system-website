﻿<html>
<head>
</head>
<body bgcolor="b5b575">
<center>
<form method="post" action="insert.php">
<fieldset>
<legend><h1>details</h1></legend>
<PRE>
<div align="left">
name				:                               <input type="text" name="name" required>


last name			:                               <input type="text" name="lname" required>


dob 			    :                               <input type="date" name="dob" required>


email			    :                               <input type="text" name="email" required>


phone 		        : 	                            <input type="text" name="phone" required>


password			:                               <input type="password" name="password" required>


confirm password 	:                               <input type="password" name="cpassword" required>
</div>


<input type="submit" name="submit" value="submit">	<input type="reset" name="reset" value="reset">
</PRE>
</fieldset>
</form>
</center>
</body>
</html>