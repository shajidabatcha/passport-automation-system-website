﻿<html>
<head>
</head>
<body background="pass.jpg">

<p><center><font color="#f5d20c"><h1><u>welcome to passport automation system</u></h1></font></p>

<H3><marquee TITLE="Holding your cursor over this stops the marquee."
            ONMOUSEOVER="this.stop();"
            ONMOUSEOUT="this.start();"
          bgcolor="#FFFFCC"  scrollamount="4"><font color="#195019" size="+3">!!passport within 30 days!!</font>
         <P><font size="-1">!!!passport automation!!!</font></P>

      </marquee></H3>



</body>
</html>


