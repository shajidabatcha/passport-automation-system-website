DEVELOPED IN B.S.ABDUR RAHMAN UNIVERSITY---ONLINE PASSPORT AUTOMATION SYSTEM



INSTRUCTOR
	Dr.R.SRIRAM

TEAM MEMBERS
	B.JAYASHREE
	120071601038

	A.LAVANYA
	120071601043

	S.NANDITHA
	120071601063
	

ONLINE PASSPORT REGISTRATION

	1.	The online passport registration system allows the user to apply for a new passport. Previously the whole process was completely carried out manually. The system allows the users to apply for a passport through online forms.


2.	The website is designed using php and mysql.  The website requires registration with the basic details of the user. The users are provided with a username and a password. The registration details are stored in the table �register�.


3.	The user have to login in order to perform the application to the passport. The username and password are validated from the actual values in the registration table. Then after successful login the site redirects to the personal information page.


4.	The personal information of the applicant is filled. Then the site redirects to the other details page. In this page the details regarding educational qualifications and marital status of the applicant is gathered. Then the website redirects to the references page. The user needs to produce the details of the references in the page. Then the site redirects to appointments page. In this page the user needs to fill the details for his/her appointment in the local passport office. Once the user successfully filled all the details all the details are displayed once and the users can logout of the site.



5.	The whole system requires 5 tables in order to store the details gathered in every page. Email is kept as the mandate column and primary key in order to refer a particular person.


6.	The applications are processed in the administrator module.


7.	As the site is designed in tamil the file format should be stored in utf-8 format. Xampp server suits the best for compiling and executing the php code. Phpmyadmin supports in the creation and maintenance of mysql database and tables.


The project was developed as a part of the curriculum for the course IP lab(CS405).