﻿<html>
<head>
<style>
.link{
background-color:#f5d20c;
color:#b5b575;
}
</style>
</head>
<body bgcolor="#b5b575">
<center>
<form method="post" action="login.php">
<fieldset>
<legend><h1>sign in to continue</h1></legend>
<p>
<pre>

email	    :	<input type="text" name="email" required size=30><br><br>
password	:	<input type ="password" name="password" required size=30><br>
	<input type="submit" name="submit" value="submit">		<input type="reset" name="reset" value="reset">

</p>
</form>
</fieldset>
</body>
</html>