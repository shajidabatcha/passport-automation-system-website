﻿<html>
<head>
</head>
<body bgcolor=#b5b575>
<center>
<form method='POST' action="self2.php">
Enter Email <input type='text' name='email' required>
<input type='submit' submit value="continue">
</form>
</center>
</body>
</html>