﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style>
.link{
background-color:#450000;
color:#b5b575;

}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body bgcolor="b5b575">
<center>
<form method="post" action="appointmentinsert.php">
<pre>
<div align="left">
<fieldset>
<legend>
<h1>appointment details</h1></legend>
passport location	:	<select name="locality">
<option value="select category">select catagories</option>
<option value="Tambaram">tambaram</option>
<option value="Sali gramam">sali gramam</option>
<option value="Aminjikarai">aminjikarai</option> 
</select>


date				:	<input type="date" name="date" required /> 


time				:	<input type="time" name="time" required />


email			    :	<input type="text" name="email" required />

<input type="submit" name="submit" value="submit" />
</div>
</pre>
</form>
<a href="self2.php" class="link">Next</a>
</fieldset></body>
</html>
