<?php
$host="localhost";
$user="root";
$pass="";
$conn=mysqli_connect($host,$user,$pass);
$db="onine_passport";
mysqli_select_db($conn,$db);
?>